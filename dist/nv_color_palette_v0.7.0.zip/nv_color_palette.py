"""A color palette dialog for novelibre.

Requires Python 3.7+
Copyright (c) Peter Triesberger
For further information see https://github.com/peter88213/nv_color_palette
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
from pathlib import Path

import gettext
import locale
import os
import sys

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation(
        'nv_color_palette',
        LOCALE_PATH,
        languages=[CURRENT_LANGUAGE],
    )
    _ = t.gettext
except:

    def _(message):
        return message

from tkinter import colorchooser
from tkinter import ttk

'''Provide global variables and functions.

Copyright (c) Peter Triesberger
For further information see https://github.com/peter88213/nv_color_palette
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)
'''

HELP_SITE = 'https://peter88213.github.io/nv_color_palette'
HELP_PAGE = 'help'

prefs = {}

PALETTES = {
    f"({_('No predefined palette')})": [],
    'chart-palettes': [
        '#004586',
        '#ff420e',
        '#ffd320',
        '#579d1c',
        '#7e0021',
        '#83caff',
        '#314004',
        '#aecf00',
        '#4b1f6f',
        '#ff950e',
        '#c5000b',
        '#0084d1',
    ],
    'compatibility': [
        '#FFFF00',
        '#00FF00',
        '#00FFFF',
        '#FF00FF',
        '#0000FF',
        '#FF0000',
        '#000080',
        '#008080',
        '#008000',
        '#800080',
        '#800000',
        '#808000',
        '#808080',
        '#C0C0C0',
    ],
    'libreoffice': [
        "#106802",
        "#18a303",
        "#43c330",
        "#92e285",
        "#ccf4c6",
        "#2cee0e",
        "#023f62",
        "#0369a3",
        "#1c99e0",
        "#63bbee",
        "#aadcf7",
        "#00a0fc",
        "#622502",
        "#a33e03",
        "#d36118",
        "#f09e6f",
        "#f9cfb5",
        "#fc5c00",
        "#530260",
        "#8e03a3",
        "#c254d2",
        "#dc85e9",
        "#f2cbf8",
        "#e327ff",
        "#876900",
        "#c99c00",
        "#e9b913",
        "#f5cd53",
        "#fde9a9",
        "#ffd74c",
    ],
    'gallery': [
        '#e5e5e5',
        '#cccccc',
        '#b2b2b2',
        '#999999',
        '#7f7f7f',
        '#666666',
        '#4c4c4c',
        '#333333',
        '#ffff70',
        '#fff726',
        '#ffde3b',
        '#ffcc00',
        '#ffb029',
        '#ff9e00',
        '#ff7f00',
        '#ff0059',
        '#7f0059',
        '#ff59ba',
        '#ffccff',
        '#ff99ff',
        '#ff7fff',
        '#ff57ff',
        '#ba3bf5',
        '#751fe3',
        '#1200de',
        '#0019fc',
        '#4c7fff',
        '#758fff',
        '#b8bfff',
        '#b8d4ff',
        '#e3f2ff',
        '#c4e5ff',
        '#7affff',
        '#63f0ff',
        '#59e5ff',
        '#3dbfff',
        '#2199ff',
        '#004cbf',
        '#00007f',
        '#7fa0ba',
        '#9eff94',
        '#52fc47',
        '#47de57',
        '#33b061',
        '#007c00',
        '#fff7ed',
        '#ffedde',
        '#ede6d1',
        '#f7e0b0',
        '#ffd97f',
        '#edccb8',
        '#e3b35c',
        '#f29930',
        '#b27f54',
        '#82210d',
        '#6e4300',
        '#756647',
        '#c2a69c',
        '#c9bfb7',
    ],
    'standard': [
        '#000080',
        '#008000',
        '#008080',
        '#800000',
        '#800080',
        '#808000',
        '#808080',
        '#c0c0c0',
        '#0000ff',
        '#00ff00',
        '#00ffff',
        '#ff0000',
        '#ff00ff',
        '#ffff00',
        '#333333',
        '#4c4c4c',
        '#666666',
        '#999999',
        '#b3b3b3',
        '#cccccc',
        '#e6e6e6',
        '#e6e6ff',
        '#ff3366',
        '#dc2300',
        '#b84700',
        '#ff3333',
        '#eb613d',
        '#b84747',
        '#b80047',
        '#99284c',
        '#94006b',
        '#94476b',
        '#944794',
        '#9966cc',
        '#6b4794',
        '#6b2394',
        '#6b0094',
        '#5e11a6',
        '#280099',
        '#4700b8',
        '#2300dc',
        '#2323dc',
        '#0047ff',
        '#0099ff',
        '#00b8ff',
        '#99ccff',
        '#cfe7f5',
        '#00dcff',
        '#00cccc',
        '#23b8dc',
        '#47b8b8',
        '#33a3a3',
        '#198a8a',
        '#006b6b',
        '#004a4a',
        '#355e00',
        '#5c8526',
        '#7da647',
        '#94bd5e',
        '#00ae00',
        '#33cc66',
        '#3deb3d',
        '#23ff23',
        '#e6ff00',
        '#ffff99',
        '#ffff66',
        '#e6e64c',
        '#cccc00',
        '#b3b300',
        '#808019',
        '#666600',
        '#4c1900',
        '#663300',
        '#804c19',
        '#996633',
        '#cc6633',
        '#ff6633',
        '#ff9966',
        '#ffcc99',
        '#9999ff',
        '#993366',
        '#ffffcc',
        '#ccffff',
        '#660066',
        '#ff8080',
        '#0066cc',
        '#004586',
        '#ff420e',
        '#ffd320',
        '#579d1c',
        '#7e0021',
        '#83caff',
        '#314004',
        '#aecf00',
        '#4b1f6f',
        '#ff950e',
        '#c5000b',
        '#0084d1',
    ],
    'html': [
        '#fffafa',
        '#f0fff0',
        '#f5fffa',
        '#f0ffff',
        '#f0f8ff',
        '#f8f8ff',
        '#f5f5f5',
        '#fff5ee',
        '#f5f5dc',
        '#fdf5e6',
        '#fffaf0',
        '#fffff0',
        '#faebd7',
        '#faf0e6',
        '#fff0f5',
        '#ffe4e1',
        '#dcdcdc',
        '#d3d3d3',
        '#C0C0C0',
        '#a9a9a9',
        '#808080',
        '#696969',
        '#778899',
        '#708090',
        '#2f4f4f',
        '#ffc0cb',
        '#ffb6c1',
        '#ff69b4',
        '#ff1493',
        '#db7093',
        '#c71585',
        '#ffa07a',
        '#fa8072',
        '#e9967a',
        '#f08080',
        '#cd5c5c',
        '#dc143c',
        '#b22222',
        '#8b0000',
        '#FF0000',
        '#ff4500',
        '#ff6347',
        '#ff7f50',
        '#ff8c00',
        '#ffa500',
        '#FFFF00',
        '#ffffe0',
        '#fffacd',
        '#fafad2',
        '#ffefd5',
        '#ffe4b5',
        '#ffdab9',
        '#eee8aa',
        '#f0e68c',
        '#bdb76b',
        '#ffd700',
        '#fff8dc',
        '#ffebcd',
        '#ffe4c4',
        '#ffdead',
        '#f5deb3',
        '#deb887',
        '#d2b48c',
        '#bc8f8f',
        '#f4a460',
        '#daa520',
        '#b8860b',
        '#cd853f',
        '#d2691e',
        '#8b4513',
        '#a0522d',
        '#a52a2a',
        '#800000',
        '#556b2f',
        '#808000',
        '#6b8e23',
        '#9acd32',
        '#32cd32',
        '#00ff00',
        '#7cfc00',
        '#7fff00',
        '#adff2f',
        '#00ff7f',
        '#00fa9a',
        '#90ee90',
        '#98fb98',
        '#8fbc8f',
        '#66cdaa',
        '#3cb371',
        '#2e8b57',
        '#228b22',
        '#008000',
        '#006400',
        '#00FFFF',
        '#e0ffff',
        '#afeeee',
        '#7fffd4',
        '#40e0d0',
        '#48d1cc',
        '#00ced1',
        '#20b2aa',
        '#5f9ea0',
        '#008b8b',
        '#008080',
        '#b0c4de',
        '#b0e0e6',
        '#add8e6',
        '#87ceeb',
        '#87cefa',
        '#00bfff',
        '#1e90ff',
        '#6495ed',
        '#4682b4',
        '#4169e1',
        '#0000FF',
        '#0000cd',
        '#00008b',
        '#000080',
        '#191970',
        '#e6e6fa',
        '#d8bfd8',
        '#dda0dd',
        '#ee82ee',
        '#da70d6',
        '#ff00ff',
        '#ba55d3',
        '#9370db',
        '#8a2be2',
        '#9400d3',
        '#9932cc',
        '#8b008b',
        '#800080',
        '#4b0082',
        '#483d8b',
        '#6a5acd',
        '#7b68ee',
        '#663399',
    ],
}

import platform


try:
    LOCALE_PATH
except NameError:
    locale.setlocale(locale.LC_TIME, "")
    LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
    try:
        CURRENT_LANGUAGE = locale.getlocale()[0][:2]
    except:
        CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
    try:
        t = gettext.translation(
            'novelibre',
            LOCALE_PATH,
            languages=[CURRENT_LANGUAGE],
        )
        _ = t.gettext
    except:

        def _(message):
            return message



class GenericKeys:

    ADD_CHILD = ('<Control-Alt-n>', f'{_("Ctrl")}-Alt-N')
    ADD_ELEMENT = ('<Control-n>', f'{_("Ctrl")}-N')
    ADD_PARENT = ('<Control-Alt-N>', f'{_("Ctrl")}-Alt-{_("Shift")}-N')
    BACK = ('<Alt-Left>', f'Alt-{_("Left")}')
    CHAPTER_LEVEL = ('<Control-Alt-c>', f'{_("Ctrl")}-Alt-C')
    COPY = ('<Control-c>', f'{_("Ctrl")}-C')
    CUT = ('<Control-x>', f'{_("Ctrl")}-X')
    DELETE = ('<Delete>', _('Del'))
    DETACH_PROPERTIES = ('<Control-Alt-d>', f'{_("Ctrl")}-Alt-D')
    FOLDER = ('<Control-p>', f'{_("Ctrl")}-P')
    FORWARD = ('<Alt-Right>', f'Alt-{_("Right")}')
    LOCK_PROJECT = ('<Control-l>', f'{_("Ctrl")}-L')
    NEXT = ('<Alt-Down>', f'Alt-{_("Down")}')
    OPEN_HELP = ('<F1>', 'F1')
    OPEN_PROJECT = ('<Control-o>', f'{_("Ctrl")}-O')
    PASTE = ('<Control-v>', f'{_("Ctrl")}-V')
    PREVIOUS = ('<Alt-Up>', f'Alt-{_("Up")}')
    QUIT_PROGRAM = ('<Control-q>', f'{_("Ctrl")}-Q')
    REFRESH_TREE = ('<F5>', 'F5')
    RELOAD_PROJECT = ('<Control-r>', f'{_("Ctrl")}-R')
    RESTORE_BACKUP = ('<Control-b>', f'{_("Ctrl")}-B')
    RESTORE_STATUS = ('<Escape>', 'Esc')
    SAVE_AS = ('<Control-S>', f'{_("Ctrl")}-{_("Shift")}-S')
    SAVE_PROJECT = ('<Control-s>', f'{_("Ctrl")}-S')
    TOGGLE_PROPERTIES = ('<Control-Alt-t>', f'{_("Ctrl")}-Alt-T')
    TOGGLE_VIEWER = ('<Control-t>', f'{_("Ctrl")}-T')
    UNDO = ('<Control-z>', f'{_("Ctrl")}-Z')
    UNLOCK_PROJECT = ('<Control-u>', f'{_("Ctrl")}-U')



class GenericMouse:

    CHOOSE_COLOR = '<Button-1>'
    LEFT_CLICK = '<Button-1>'
    MOVE_NODE = '<B1-Motion>'
    RESET_COLOR = '<Shift-Button-1>'
    RIGHT_CLICK = '<Button-3>'


class MacKeys(GenericKeys):

    ADD_CHILD = ('<Command-Option-n>', 'Cmd-Option-N')
    ADD_ELEMENT = ('<Command-n>', 'Cmd-N')
    ADD_PARENT = ('<Command-Option-N>', 'Cmd-Option-Shift-N')
    BACK = ('<Option-Left>', f'Option-{_("Left")}')
    CHAPTER_LEVEL = ('<Command-Option-c>', 'Cmd-Option-C')
    COPY = ('<Command-c>', 'Cmd-C')
    CUT = ('<Command-x>', 'Cmd-X')
    DETACH_PROPERTIES = ('<Command-Option-d>', 'Cmd-Option-D')
    FOLDER = ('<Command-p>', 'Cmd-P')
    FORWARD = ('<Option-Right>', f'Option-{_("Right")}')
    LOCK_PROJECT = ('<Command-l>', 'Cmd-L')
    NEXT = ('<Option-Down>', f'Option-{_("Down")}')
    OPEN_PROJECT = ('<Command-o>', 'Cmd-O')
    PASTE = ('<Command-v>', 'Cmd-V')
    PREVIOUS = ('<Option-Up>', f'Option-{_("Up")}')
    QUIT_PROGRAM = ('<Command-q>', 'Cmd-Q')
    RELOAD_PROJECT = ('<Command-r>', 'Cmd-R')
    RESTORE_BACKUP = ('<Command-b>', 'Cmd-B')
    SAVE_AS = ('<Command-S>', 'Cmd-Shift-S')
    SAVE_PROJECT = ('<Command-s>', 'Cmd-S')
    TOGGLE_PROPERTIES = ('<Command-Option-t>', 'Cmd-Option-T')
    TOGGLE_VIEWER = ('<Command-t>', 'Cmd-T')
    UNDO = ('<Command-z>', 'Cmd-Z')
    UNLOCK_PROJECT = ('<Command-u>', 'Cmd-U')



class MacMouse(GenericMouse):

    RIGHT_CLICK = '<Button-2>'


class WindowsKeys(GenericKeys):

    QUIT_PROGRAM = ('<Alt-F4>', 'Alt-F4')


class WindowsMouse(GenericMouse):

    BACK_CLICK = '<Button-4>'
    FORWARD_CLICK = '<Button-5>'

if platform.system() == 'Windows':
    PLATFORM = 'win'
    KEYS = WindowsKeys()
    MOUSE = WindowsMouse()
elif platform.system() in ('Linux', 'FreeBSD'):
    PLATFORM = 'ix'
    KEYS = GenericKeys()
    MOUSE = GenericMouse()
elif platform.system() == 'Darwin':
    PLATFORM = 'mac'
    KEYS = MacKeys()
    MOUSE = MacMouse()
else:
    PLATFORM = ''
    KEYS = GenericKeys()
    MOUSE = GenericMouse()

from abc import abstractmethod

import tkinter as tk


class ModalDialog(tk.Toplevel):
    OFFSET = 300

    @abstractmethod
    def __init__(self, ui, **kw):
        tk.Toplevel.__init__(self, **kw)
        __, x, y = ui.root.geometry().split('+')
        windowGeometry = f'+{int(x)+self.OFFSET}+{int(y)+self.OFFSET}'
        self.geometry(windowGeometry)
        self.wait_visibility()
        self.grab_set()
        self.focus()
        self.wm_attributes('-topmost', True)



class MyStringVar(tk.StringVar):

    def set(self, value):
        if value is None:
            value = ''
        super().set(value)

    def get(self, default=None):
        value = super().get()
        if value == '':
            value = default
            if default is not None:
                self.set(default)
        return value


class HexColor:

    @classmethod
    def get_luminance(cls, hexColor):
        color = hexColor[1:]
        hexRed = int(color[0:2], base=16)
        hexGreen = int(color[2:4], base=16)
        hexBlue = int(color[4:6], base=16)
        return hexRed * 0.2126 + hexGreen * 0.7152 + hexBlue * 0.0722

    @classmethod
    def is_dark(cls, hexColor):
        if cls.is_hex_color(hexColor):
            return cls.get_luminance(hexColor) < 140

        return None

    @classmethod
    def is_hex_color(cls, s):
        try:
            if len(s) == 7 and s.startswith('#'):
                return all(c in '0123456789abcdefABCDEF' for c in s[1:])

        except:
            return False



class PaletteView(ModalDialog):

    COLORS_PER_ROW = 12
    COLOR_FIELD_WIDTH = 2

    def __init__(self, chooser, ui, controller, title, initialcolor, **kw):

        def modify_custom_palette(event=None):
            if self._color in prefs['custom_palette']:
                prefs['custom_palette'].remove(self._color)
            else:

                prefs['custom_palette'].append(self._color)
            self._draw_color_palette(
                customPaletteArea,
                prefs['custom_palette'],
            )
            self._config_modify_custom_palette_button()

        def cancel():
            self.destroy()

        def change_predefined_palette(event=None):
            prefs['palette_index'] = palettes.index(
                self._predefinedPaletteVar.get()
            )
            self._draw_color_palette(
                predefinedPaletteArea,
                PALETTES[
                    palettes[prefs['palette_index']]
                ]
            )

        def choose_color():
            self._system_chooser_is_active = True
            color = colorchooser.askcolor(
                parent=self,
                title=title,
                color=self._color,
            )[1]
            self._system_chooser_is_active = False
            if color is not None:
                self._set_current_color(color)

        def get_color_entry(event=None):
            color = self._colorVar.get()
            if HexColor.is_hex_color(color):
                self._set_current_color(color)
            else:
                self._colorVar.set(self._color)

        def on_quit(event=None):
            if self._system_chooser_is_active:
                return 'break'

            self.destroy()

        def open_help_page(event=None):
            self._ctrl.open_help(
                page=HELP_PAGE,
                site=HELP_SITE
            )

        def return_color():
            self._chooser.color = self._color
            self.destroy()

        super().__init__(ui, **kw)
        self._ctrl = controller

        self.resizable(0, 0)
        self.attributes('-toolwindow', True)
        self.title(title)
        self.protocol("WM_DELETE_WINDOW", on_quit)

        self._system_chooser_is_active = False

        self._chooser = chooser
        self._chooser.color = None
        self._color = initialcolor

        mainPrefs = self._ctrl.get_preferences()
        initialcolor = initialcolor or mainPrefs['color_text_fg']

        palettes = list(PALETTES)
        self._predefinedPaletteVar = tk.StringVar()
        ttk.OptionMenu(
            self,
            self._predefinedPaletteVar,
            palettes[int(prefs['palette_index'])],
            *palettes,
            command=change_predefined_palette,
        ).pack(anchor='w')

        predefinedPaletteArea = ttk.Frame(self)
        predefinedPaletteArea.pack(
            padx=5,
            pady=5,
            fill='both',
            expand=True,
        )

        ttk.Separator(
            self,
            orient='horizontal',
        ).pack(fill='x')


        customPaletteHeader = ttk.Frame(self)
        customPaletteHeader.pack(
            fill='both',
            expand=False,
        )
        ttk.Label(
            customPaletteHeader,
            text=_('Custom palette'),
        ).pack(
            side='left',
            padx=5,
            pady=5,
        )

        self._modifyCustomPaletteButton = ttk.Button(
            customPaletteHeader,
            command=modify_custom_palette,
        )
        self._modifyCustomPaletteButton.pack(
            side='right',
            padx=5,
            pady=5,
            fill='x',
            expand=True,
        )
        customPaletteArea = ttk.Frame(self)
        customPaletteArea.pack(
            padx=5,
            pady=5,
            fill='both',
            expand=True,
        )

        ttk.Separator(
            self,
            orient='horizontal',
        ).pack(fill='x')

        colorEntryWindow = ttk.Frame(self)
        colorEntryWindow.pack(
            fill='x',
            expand=False,
        )

        self._colorVar = MyStringVar(value=initialcolor)
        colorEntry = ttk.Entry(
            colorEntryWindow,
            textvariable=self._colorVar,
        )
        colorEntry.bind('<Return>', get_color_entry)
        colorEntry.pack(
            padx=5,
            pady=5,
            side='left',
        )

        ttk.Button(
            colorEntryWindow,
            text=_('Color chooser'),
            command=choose_color,
        ).pack(
            padx=5,
            pady=5,
            side='right',
            fill='x',
            expand=True,
        )

        ttk.Separator(
            self,
            orient='horizontal',
        ).pack(fill='x')

        previewWindow = ttk.Frame(self)
        previewWindow.pack(
            padx=5,
            pady=5,
            fill='both',
            expand=False,
        )

        self._currentColorPreviewInv = tk.Label(
            previewWindow,
            text=_('Background'),
        )
        self._currentColorPreviewInv.pack(side='right', fill='x', expand=True)

        self._currentColorPreview = tk.Label(
            previewWindow,
            text=_('Foreground'),
            bg=mainPrefs['color_text_bg'],
        )
        self._currentColorPreview.pack(side='left', fill='x', expand=True)

        ttk.Separator(
            self,
            orient='horizontal',
        ).pack(fill='x')
        footer = tk.Frame(self)
        footer.pack(
            fill='both',
            expand=False,
        )

        ttk.Button(
            footer,
            text=_('Cancel'),
            command=cancel,
        ).pack(padx=5, pady=5, side='right')

        ttk.Button(
            footer,
            text=_('Help'),
            command=open_help_page,
        ).pack(padx=5, pady=5, side='right')

        ttk.Button(
            footer,
            text=_('Apply'),
            command=return_color,
        ).pack(padx=5, pady=5, side='right')

        self.bind(KEYS.OPEN_HELP[0], open_help_page)

        self._draw_color_palette(
            predefinedPaletteArea,
            PALETTES[
                palettes[prefs['palette_index']]
            ]
        )
        self._draw_color_palette(
            customPaletteArea,
            prefs['custom_palette'],
        )
        self._set_current_color(initialcolor)
        self._config_modify_custom_palette_button()

    def _config_modify_custom_palette_button(self):
        self._modifyCustomPaletteButton['text'] = (
            _('Remove selected color') if self._color in prefs['custom_palette']
            else _('Add selected color')
        )

    def _draw_color_palette(self, paletteArea, palette):

        for child in paletteArea.winfo_children():
            child.destroy()
        paletteView = ttk.Frame(paletteArea)
        paletteView.pack(fill='both', expand=True)

        for i, color in enumerate(palette):
            tk.Button(
                paletteView,
                relief='flat',
                overrelief='raised',
                bg=color,
                width=self.COLOR_FIELD_WIDTH,
                command=lambda c=color: self._set_current_color(c),
            ).grid(
                row=i // self.COLORS_PER_ROW,
                column=i % self.COLORS_PER_ROW,
                padx=5,
                pady=5,
            )

    def _set_current_color(self, color):

        def contrast_color(c):
            contrastCol = '#ffffff' if HexColor.is_dark(c) else '#000000'
            return contrastCol

        self._color = color
        self._currentColorPreviewInv['bg'] = color
        self._currentColorPreviewInv['fg'] = contrast_color(color)
        self._currentColorPreview['fg'] = color
        self._colorVar.set(self._color)
        self._config_modify_custom_palette_button()



def set_icon(widget, icon='logo', path=None, default=True):
    if path is None:
        path = os.path.dirname(sys.argv[0])
        if not path:
            path = '.'
        path = f'{path}/icons'
    try:
        pic = tk.PhotoImage(file=f'{path}/{icon}.png')
        widget.iconphoto(default, pic)
    except:
        return False

    return True



class NvColorChooser:

    def __init__(self, ui, controller):
        self._ui = ui
        self._ctrl = controller
        self.color = None

    def choose_color(self, title='', initialcolor=None):
        palette = PaletteView(self, self._ui, self._ctrl, title, initialcolor)
        set_icon(palette, icon='colors', default=False)
        palette.wait_window(palette)

        return self.color
import json

from abc import ABC, abstractmethod


class ConfigurationBase(ABC):

    def __init__(self, settings=None, options=None, filePath=None):
        self.settings = None
        self.options = None
        self.filePath = filePath
        self.strLabel = 'SETTINGS'
        self.boolLabel = 'OPTIONS'
        self.set(
            settings=settings,
            options=options,
        )

    @abstractmethod
    def read(self):
        pass

    def set(self, settings=None, options=None):
        self.settings = (settings or {}).copy()
        self.options = (options or {}).copy()

    @abstractmethod
    def write(self):
        pass



class ConfigurationJson(ConfigurationBase):

    def read(self):
        try:
            with open(self.filePath, 'r', encoding='utf-8') as f:
                config = json.load(f)
        except FileNotFoundError:
            config = {}
        if self.strLabel in config:
            section = config[self.strLabel]
            for setting in self.settings:
                fallback = self.settings[setting]
                self.settings[setting] = section.get(setting, fallback)
        if self.boolLabel in config:
            section = config[self.boolLabel]
            for option in self.options:
                fallback = self.options[option]
                self.options[option] = section.get(option, fallback)

    def write(self):
        with open(self.filePath, 'w', encoding='utf-8') as f:
            config = {}
            if self.settings:
                config[self.strLabel] = self.settings
            if self.options:
                config[self.boolLabel] = self.options
            json.dump(
                config,
                f,
                ensure_ascii=False,
                indent=4,
            )
from abc import ABC, abstractmethod
from pathlib import Path



class SubController:

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_open(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass



class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''
    HELP_SITE = None
    HELP_PAGE = None

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

        self._icon = None

    @abstractmethod
    def install(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def uninstall(self):
        pass

    def _add_help_menu_entry(self, label):

        def open_help():
            self._ctrl.open_help(
                page=self.HELP_PAGE,
                site=self.HELP_SITE
            )

        self._ui.helpMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            command=open_help,
        )

    def _get_icon(self, fileName):
        if self._ctrl.get_preferences().get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
            icon = tk.PhotoImage(file=f'{iconPath}/{fileName}')
        except:
            icon = None
        return icon


class Plugin(PluginBase):
    VERSION = '0.7.0'
    API_VERSION = '5.63'
    DESCRIPTION = 'Color palette dialog'
    URL = 'https://github.com/peter88213/nv_color_palette'
    HELP_SITE = HELP_SITE
    HELP_PAGE = HELP_PAGE
    INI_FILENAME = 'color_palette.json'
    INI_FILEPATH = '.novx/config'

    SETTINGS = dict(
        palette_index=1,
        custom_palette=[],
    )
    OPTIONS = {}

    def install(self, model, view, controller):
        """Install the plugin at runtime.
        
        Positional arguments:
            model -- reference to the novelibre main model instance.
            view -- reference to the novelibre main view instance.
            controller -- reference to the novelibre main controller instance.

        Extends the superclass method.
        """
        super().install(model, view, controller)
        self._icon = self._get_icon('colors.png')


        self._add_help_menu_entry(_('Color palette plugin help'))

        try:
            homeDir = str(Path.home()).replace('\\', '/')
            configDir = f'{homeDir}/{self.INI_FILEPATH}'
        except:
            configDir = '.'
        self._configuration = ConfigurationJson(
            settings=self.SETTINGS,
            options=self.OPTIONS,
            filePath=f'{configDir}/{self.INI_FILENAME}',
        )
        self._configuration.read()
        prefs.update(self._configuration.settings)
        prefs.update(self._configuration.options)


        self._ui.colorChooser = NvColorChooser(self._ui, self._ctrl)

    def on_quit(self):
        for keyword in prefs:
            if keyword in self._configuration.options:
                self._configuration.options[keyword] = prefs[keyword]
            elif keyword in self._configuration.settings:
                self._configuration.settings[keyword] = prefs[keyword]
        self._configuration.write()
        self._ui.colorChooser.on_quit()
