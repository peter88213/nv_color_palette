"""A color palette dialog for novelibre.

Requires Python 3.7+
Copyright (c) Peter Triesberger
For further information see https://github.com/peter88213/nv_color_palette
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import gettext
import locale
import os
import sys

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation(
        'nv_color_palette',
        LOCALE_PATH,
        languages=[CURRENT_LANGUAGE],
    )
    _ = t.gettext
except:

    def _(message):
        return message

from tkinter import ttk


HELP_SITE = 'https://peter88213.github.io/nv_color_palette'
HELP_PAGE = _('help')
import platform


try:
    LOCALE_PATH
except NameError:
    locale.setlocale(locale.LC_TIME, "")
    LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
    try:
        CURRENT_LANGUAGE = locale.getlocale()[0][:2]
    except:
        CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
    try:
        t = gettext.translation(
            'novelibre',
            LOCALE_PATH,
            languages=[CURRENT_LANGUAGE],
        )
        _ = t.gettext
    except:

        def _(message):
            return message



class GenericKeys:

    ADD_CHILD = ('<Control-Alt-n>', f'{_("Ctrl")}-Alt-N')
    ADD_ELEMENT = ('<Control-n>', f'{_("Ctrl")}-N')
    ADD_PARENT = ('<Control-Alt-N>', f'{_("Ctrl")}-Alt-{_("Shift")}-N')
    BACK = ('<Alt-Left>', f'Alt-{_("Left")}')
    CHAPTER_LEVEL = ('<Control-Alt-c>', f'{_("Ctrl")}-Alt-C')
    COPY = ('<Control-c>', f'{_("Ctrl")}-C')
    CUT = ('<Control-x>', f'{_("Ctrl")}-X')
    DELETE = ('<Delete>', _('Del'))
    DETACH_PROPERTIES = ('<Control-Alt-d>', f'{_("Ctrl")}-Alt-D')
    FOLDER = ('<Control-p>', f'{_("Ctrl")}-P')
    FORWARD = ('<Alt-Right>', f'Alt-{_("Right")}')
    LOCK_PROJECT = ('<Control-l>', f'{_("Ctrl")}-L')
    NEXT = ('<Alt-Down>', f'Alt-{_("Down")}')
    OPEN_HELP = ('<F1>', 'F1')
    OPEN_PROJECT = ('<Control-o>', f'{_("Ctrl")}-O')
    PASTE = ('<Control-v>', f'{_("Ctrl")}-V')
    PREVIOUS = ('<Alt-Up>', f'Alt-{_("Up")}')
    QUIT_PROGRAM = ('<Control-q>', f'{_("Ctrl")}-Q')
    REFRESH_TREE = ('<F5>', 'F5')
    RELOAD_PROJECT = ('<Control-r>', f'{_("Ctrl")}-R')
    RESTORE_BACKUP = ('<Control-b>', f'{_("Ctrl")}-B')
    RESTORE_STATUS = ('<Escape>', 'Esc')
    SAVE_AS = ('<Control-S>', f'{_("Ctrl")}-{_("Shift")}-S')
    SAVE_PROJECT = ('<Control-s>', f'{_("Ctrl")}-S')
    TOGGLE_PROPERTIES = ('<Control-Alt-t>', f'{_("Ctrl")}-Alt-T')
    TOGGLE_VIEWER = ('<Control-t>', f'{_("Ctrl")}-T')
    UNDO = ('<Control-z>', f'{_("Ctrl")}-Z')
    UNLOCK_PROJECT = ('<Control-u>', f'{_("Ctrl")}-U')



class GenericMouse:

    CHOOSE_COLOR = '<Button-1>'
    LEFT_CLICK = '<Button-1>'
    MOVE_NODE = '<B1-Motion>'
    RESET_COLOR = '<Shift-Button-1>'
    RIGHT_CLICK = '<Button-3>'


class MacKeys(GenericKeys):

    ADD_CHILD = ('<Command-Option-n>', 'Cmd-Option-N')
    ADD_ELEMENT = ('<Command-n>', 'Cmd-N')
    ADD_PARENT = ('<Command-Option-N>', 'Cmd-Option-Shift-N')
    BACK = ('<Option-Left>', f'Option-{_("Left")}')
    CHAPTER_LEVEL = ('<Command-Option-c>', 'Cmd-Option-C')
    COPY = ('<Command-c>', 'Cmd-C')
    CUT = ('<Command-x>', 'Cmd-X')
    DETACH_PROPERTIES = ('<Command-Option-d>', 'Cmd-Option-D')
    FOLDER = ('<Command-p>', 'Cmd-P')
    FORWARD = ('<Option-Right>', f'Option-{_("Right")}')
    LOCK_PROJECT = ('<Command-l>', 'Cmd-L')
    NEXT = ('<Option-Down>', f'Option-{_("Down")}')
    OPEN_PROJECT = ('<Command-o>', 'Cmd-O')
    PASTE = ('<Command-v>', 'Cmd-V')
    PREVIOUS = ('<Option-Up>', f'Option-{_("Up")}')
    QUIT_PROGRAM = ('<Command-q>', 'Cmd-Q')
    RELOAD_PROJECT = ('<Command-r>', 'Cmd-R')
    RESTORE_BACKUP = ('<Command-b>', 'Cmd-B')
    SAVE_AS = ('<Command-S>', 'Cmd-Shift-S')
    SAVE_PROJECT = ('<Command-s>', 'Cmd-S')
    TOGGLE_PROPERTIES = ('<Command-Option-t>', 'Cmd-Option-T')
    TOGGLE_VIEWER = ('<Command-t>', 'Cmd-T')
    UNDO = ('<Command-z>', 'Cmd-Z')
    UNLOCK_PROJECT = ('<Command-u>', 'Cmd-U')



class MacMouse(GenericMouse):

    RIGHT_CLICK = '<Button-2>'


class WindowsKeys(GenericKeys):

    QUIT_PROGRAM = ('<Alt-F4>', 'Alt-F4')


class WindowsMouse(GenericMouse):

    BACK_CLICK = '<Button-4>'
    FORWARD_CLICK = '<Button-5>'

if platform.system() == 'Windows':
    PLATFORM = 'win'
    KEYS = WindowsKeys()
    MOUSE = WindowsMouse()
elif platform.system() in ('Linux', 'FreeBSD'):
    PLATFORM = 'ix'
    KEYS = GenericKeys()
    MOUSE = GenericMouse()
elif platform.system() == 'Darwin':
    PLATFORM = 'mac'
    KEYS = MacKeys()
    MOUSE = MacMouse()
else:
    PLATFORM = ''
    KEYS = GenericKeys()
    MOUSE = GenericMouse()

from abc import abstractmethod

import tkinter as tk


class ModalDialog(tk.Toplevel):
    OFFSET = 300

    @abstractmethod
    def __init__(self, ui, **kw):
        tk.Toplevel.__init__(self, **kw)
        __, x, y = ui.root.geometry().split('+')
        windowGeometry = f'+{int(x)+self.OFFSET}+{int(y)+self.OFFSET}'
        self.geometry(windowGeometry)
        self.grab_set()
        self.focus()
        self.wm_attributes('-topmost', True)



class HexColor:

    @classmethod
    def get_luminance(cls, hexColor):
        color = hexColor[1:]
        hexRed = int(color[0:2], base=16)
        hexGreen = int(color[2:4], base=16)
        hexBlue = int(color[4:6], base=16)
        return hexRed * 0.2126 + hexGreen * 0.7152 + hexBlue * 0.0722

    @classmethod
    def is_dark(cls, hexColor):
        try:
            if hexColor.startswith('#'):
                return cls.get_luminance(hexColor) < 140

        except:
            pass
        return None



class PaletteView(ModalDialog):

    def __init__(self, chooser, ui, controller, title, initialcolor, **kw):

        def cancel():
            self.destroy()

        def contrast_color(c):
            contrastCol = '#ffffff' if HexColor.is_dark(c) else '#000000'
            return contrastCol

        def open_help_page(event=None):
            self._ctrl.open_help(
                page=HELP_PAGE,
                site=HELP_SITE
            )

        def return_color():
            self._chooser.color = self._color
            self.destroy()

        def set_current_color(color):
            self._color = color
            self._currentColorBg['bg'] = color
            self._currentColorBg['fg'] = contrast_color(color)
            self._currentColorFg['fg'] = color

        super().__init__(ui, **kw)
        self._ctrl = controller
        self.title(title)

        self._chooser = chooser
        self._chooser.color = None
        self._color = None

        prefs = self._ctrl.get_preferences()
        initialcolor = initialcolor or prefs['color_text_fg']

        self._paletteArea = ttk.Frame(self)
        self._paletteArea.pack(fill='both', expand=True)

        ttk.Separator(
            self,
            orient='horizontal',
        ).pack(fill='x')

        self._preview = ttk.Frame(self)
        self._preview.pack(fill='both', expand=False)

        self._currentColorBg = tk.Label(
            self._preview,
            text=_('Inverted display'),
            fg=contrast_color(initialcolor),
            bg=initialcolor,
        )
        self._currentColorBg.pack(side='right', fill='x', expand=True)

        self._currentColorFg = tk.Label(
            self._preview,
            text=_('Regulas display'),
            fg=initialcolor,
            bg=prefs['color_text_bg'],
        )
        self._currentColorFg.pack(side='left', fill='x', expand=True)

        ttk.Separator(
            self,
            orient='horizontal',
        ).pack(fill='x')

        self._footer = ttk.Frame(self)
        self._footer.pack(fill='both', expand=False)

        ttk.Button(
            self._footer,
            text=_('Cancel'),
            command=cancel,
        ).pack(padx=5, pady=5, side='right')

        ttk.Button(
            self._footer,
            text=_('Help'),
            command=open_help_page,
        ).pack(padx=5, pady=5, side='right')

        ttk.Button(
            self._footer,
            text=_('Ok'),
            command=return_color,
        ).pack(padx=5, pady=5, side='right')

        self.bind(KEYS.OPEN_HELP[0], open_help_page)

        COLORS_PER_ROW = 10
        COLOR_FIELD_WIDTH = 5
        colors = [
          "#004586",
          "#ff420e",
          "#ffd320",
          "#579d1c",
          "#7e0021",
          "#83caff",
          "#314004",
          "#aecf00",
          "#4b1f6f",
          "#ff950e",
          "#c5000b",
          "#0084d1",
          "#106802",
          "#18a303",
          "#43c330",
          "#92e285",
          "#ccf4c6",
          "#2cee0e",
          "#023f62",
          "#0369a3",
          "#1c99e0",
          "#63bbee",
          "#aadcf7",
          "#00a0fc",
          "#622502",
          "#a33e03",
          "#d36118",
          "#f09e6f",
          "#f9cfb5",
          "#fc5c00",
          "#530260",
          "#8e03a3",
          "#c254d2",
          "#dc85e9",
          "#f2cbf8",
          "#e327ff",
          "#876900",
          "#c99c00",
          "#e9b913",
          "#f5cd53",
          "#fde9a9",
          "#ffd74c",
        ]
        for i, color in enumerate(colors):
            tk.Button(
                self._paletteArea,
                bg=color,
                width=COLOR_FIELD_WIDTH,
                command=lambda c=color: set_current_color(c),
            ).grid(
                row=i // COLORS_PER_ROW,
                column=i % COLORS_PER_ROW,
                padx=5,
                pady=5,
            )



class NvColorChooser:

    def __init__(self, ui, controller):
        self._ui = ui
        self._ctrl = controller
        self.color = None

    def choose_color(self, title='', initialcolor=None):
        palette = PaletteView(self, self._ui, self._ctrl, title, initialcolor)
        palette.wait_window(palette)

        return self.color
from abc import ABC, abstractmethod
from pathlib import Path



class SubController:

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_open(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass



class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''
    HELP_SITE = None
    HELP_PAGE = None

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

        self._icon = None

    @abstractmethod
    def install(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def uninstall(self):
        pass

    def _add_help_menu_entry(self, label):

        def open_help():
            self._ctrl.open_help(
                page=self.HELP_PAGE,
                site=self.HELP_SITE
            )

        self._ui.helpMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            command=open_help,
        )

    def _get_icon(self, fileName):
        if self._ctrl.get_preferences().get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
            icon = tk.PhotoImage(file=f'{iconPath}/{fileName}')
        except:
            icon = None
        return icon


class Plugin(PluginBase):
    VERSION = '0.3.0'
    API_VERSION = '5.63'
    DESCRIPTION = 'Color palette dialog'
    URL = 'https://github.com/peter88213/nv_color_palette'
    HELP_SITE = HELP_SITE
    HELP_PAGE = HELP_PAGE

    def install(self, model, view, controller):
        """Install the plugin at runtime.
        
        Positional arguments:
            model -- reference to the novelibre main model instance.
            view -- reference to the novelibre main view instance.
            controller -- reference to the novelibre main controller instance.

        Extends the superclass method.
        """
        super().install(model, view, controller)
        self._icon = self._get_icon('colors.png')


        self._add_help_menu_entry(_('Color palette plugin help'))


        self._ui.colorChooser = NvColorChooser(self._ui, self._ctrl)

