"""A color palette dialog for novelibre.

Requires Python 3.7+
Copyright (c) Peter Triesberger
For further information see https://github.com/peter88213/nv_color_palette
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import gettext
import locale
import os
import sys

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation(
        'nv_color_palette',
        LOCALE_PATH,
        languages=[CURRENT_LANGUAGE],
    )
    _ = t.gettext
except:

    def _(message):
        return message

from tkinter import ttk

'''Provide global variables and functions.

Copyright (c) Peter Triesberger
For further information see https://github.com/peter88213/nv_color_palette
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)
'''
HELP_SITE = 'https://peter88213.github.io/nv_color_palette'
HELP_PAGE = 'help'

COLORS = [
    '#000080',
    '#008000',
    '#008080',
    '#800000',
    '#800080',
    '#808000',
    '#808080',
    '#c0c0c0',
    '#0000ff',
    '#00ff00',
    '#00ffff',
    '#ff0000',
    '#ff00ff',
    '#ffff00',
    '#ffffff',
    '#333333',
    '#4c4c4c',
    '#666666',
    '#999999',
    '#b3b3b3',
    '#cccccc',
    '#e6e6e6',
    '#e6e6ff',
    '#ff3366',
    '#dc2300',
    '#b84700',
    '#ff3333',
    '#eb613d',
    '#b84747',
    '#b80047',
    '#99284c',
    '#94006b',
    '#94476b',
    '#944794',
    '#9966cc',
    '#6b4794',
    '#6b2394',
    '#6b0094',
    '#5e11a6',
    '#280099',
    '#4700b8',
    '#2300dc',
    '#2323dc',
    '#0047ff',
    '#0099ff',
    '#00b8ff',
    '#99ccff',
    '#cfe7f5',
    '#00dcff',
    '#00cccc',
    '#23b8dc',
    '#47b8b8',
    '#33a3a3',
    '#198a8a',
    '#006b6b',
    '#004a4a',
    '#355e00',
    '#5c8526',
    '#7da647',
    '#94bd5e',
    '#00ae00',
    '#33cc66',
    '#3deb3d',
    '#23ff23',
    '#e6ff00',
    '#ffff99',
    '#ffff66',
    '#e6e64c',
    '#cccc00',
    '#b3b300',
    '#808019',
    '#666600',
    '#4c1900',
    '#663300',
    '#804c19',
    '#996633',
    '#cc6633',
    '#ff6633',
    '#ff9966',
    '#ffcc99',
    '#9999ff',
    '#993366',
    '#ffffcc',
    '#ccffff',
    '#660066',
    '#ff8080',
    '#0066cc',
    '#004586',
    '#ff420e',
    '#ffd320',
    '#579d1c',
    '#7e0021',
    '#83caff',
    '#314004',
    '#aecf00',
    '#4b1f6f',
    '#ff950e',
    '#c5000b',
    '#0084d1',
]
import platform


try:
    LOCALE_PATH
except NameError:
    locale.setlocale(locale.LC_TIME, "")
    LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
    try:
        CURRENT_LANGUAGE = locale.getlocale()[0][:2]
    except:
        CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
    try:
        t = gettext.translation(
            'novelibre',
            LOCALE_PATH,
            languages=[CURRENT_LANGUAGE],
        )
        _ = t.gettext
    except:

        def _(message):
            return message



class GenericKeys:

    ADD_CHILD = ('<Control-Alt-n>', f'{_("Ctrl")}-Alt-N')
    ADD_ELEMENT = ('<Control-n>', f'{_("Ctrl")}-N')
    ADD_PARENT = ('<Control-Alt-N>', f'{_("Ctrl")}-Alt-{_("Shift")}-N')
    BACK = ('<Alt-Left>', f'Alt-{_("Left")}')
    CHAPTER_LEVEL = ('<Control-Alt-c>', f'{_("Ctrl")}-Alt-C')
    COPY = ('<Control-c>', f'{_("Ctrl")}-C')
    CUT = ('<Control-x>', f'{_("Ctrl")}-X')
    DELETE = ('<Delete>', _('Del'))
    DETACH_PROPERTIES = ('<Control-Alt-d>', f'{_("Ctrl")}-Alt-D')
    FOLDER = ('<Control-p>', f'{_("Ctrl")}-P')
    FORWARD = ('<Alt-Right>', f'Alt-{_("Right")}')
    LOCK_PROJECT = ('<Control-l>', f'{_("Ctrl")}-L')
    NEXT = ('<Alt-Down>', f'Alt-{_("Down")}')
    OPEN_HELP = ('<F1>', 'F1')
    OPEN_PROJECT = ('<Control-o>', f'{_("Ctrl")}-O')
    PASTE = ('<Control-v>', f'{_("Ctrl")}-V')
    PREVIOUS = ('<Alt-Up>', f'Alt-{_("Up")}')
    QUIT_PROGRAM = ('<Control-q>', f'{_("Ctrl")}-Q')
    REFRESH_TREE = ('<F5>', 'F5')
    RELOAD_PROJECT = ('<Control-r>', f'{_("Ctrl")}-R')
    RESTORE_BACKUP = ('<Control-b>', f'{_("Ctrl")}-B')
    RESTORE_STATUS = ('<Escape>', 'Esc')
    SAVE_AS = ('<Control-S>', f'{_("Ctrl")}-{_("Shift")}-S')
    SAVE_PROJECT = ('<Control-s>', f'{_("Ctrl")}-S')
    TOGGLE_PROPERTIES = ('<Control-Alt-t>', f'{_("Ctrl")}-Alt-T')
    TOGGLE_VIEWER = ('<Control-t>', f'{_("Ctrl")}-T')
    UNDO = ('<Control-z>', f'{_("Ctrl")}-Z')
    UNLOCK_PROJECT = ('<Control-u>', f'{_("Ctrl")}-U')



class GenericMouse:

    CHOOSE_COLOR = '<Button-1>'
    LEFT_CLICK = '<Button-1>'
    MOVE_NODE = '<B1-Motion>'
    RESET_COLOR = '<Shift-Button-1>'
    RIGHT_CLICK = '<Button-3>'


class MacKeys(GenericKeys):

    ADD_CHILD = ('<Command-Option-n>', 'Cmd-Option-N')
    ADD_ELEMENT = ('<Command-n>', 'Cmd-N')
    ADD_PARENT = ('<Command-Option-N>', 'Cmd-Option-Shift-N')
    BACK = ('<Option-Left>', f'Option-{_("Left")}')
    CHAPTER_LEVEL = ('<Command-Option-c>', 'Cmd-Option-C')
    COPY = ('<Command-c>', 'Cmd-C')
    CUT = ('<Command-x>', 'Cmd-X')
    DETACH_PROPERTIES = ('<Command-Option-d>', 'Cmd-Option-D')
    FOLDER = ('<Command-p>', 'Cmd-P')
    FORWARD = ('<Option-Right>', f'Option-{_("Right")}')
    LOCK_PROJECT = ('<Command-l>', 'Cmd-L')
    NEXT = ('<Option-Down>', f'Option-{_("Down")}')
    OPEN_PROJECT = ('<Command-o>', 'Cmd-O')
    PASTE = ('<Command-v>', 'Cmd-V')
    PREVIOUS = ('<Option-Up>', f'Option-{_("Up")}')
    QUIT_PROGRAM = ('<Command-q>', 'Cmd-Q')
    RELOAD_PROJECT = ('<Command-r>', 'Cmd-R')
    RESTORE_BACKUP = ('<Command-b>', 'Cmd-B')
    SAVE_AS = ('<Command-S>', 'Cmd-Shift-S')
    SAVE_PROJECT = ('<Command-s>', 'Cmd-S')
    TOGGLE_PROPERTIES = ('<Command-Option-t>', 'Cmd-Option-T')
    TOGGLE_VIEWER = ('<Command-t>', 'Cmd-T')
    UNDO = ('<Command-z>', 'Cmd-Z')
    UNLOCK_PROJECT = ('<Command-u>', 'Cmd-U')



class MacMouse(GenericMouse):

    RIGHT_CLICK = '<Button-2>'


class WindowsKeys(GenericKeys):

    QUIT_PROGRAM = ('<Alt-F4>', 'Alt-F4')


class WindowsMouse(GenericMouse):

    BACK_CLICK = '<Button-4>'
    FORWARD_CLICK = '<Button-5>'

if platform.system() == 'Windows':
    PLATFORM = 'win'
    KEYS = WindowsKeys()
    MOUSE = WindowsMouse()
elif platform.system() in ('Linux', 'FreeBSD'):
    PLATFORM = 'ix'
    KEYS = GenericKeys()
    MOUSE = GenericMouse()
elif platform.system() == 'Darwin':
    PLATFORM = 'mac'
    KEYS = MacKeys()
    MOUSE = MacMouse()
else:
    PLATFORM = ''
    KEYS = GenericKeys()
    MOUSE = GenericMouse()

from abc import abstractmethod

import tkinter as tk


class ModalDialog(tk.Toplevel):
    OFFSET = 300

    @abstractmethod
    def __init__(self, ui, **kw):
        tk.Toplevel.__init__(self, **kw)
        __, x, y = ui.root.geometry().split('+')
        windowGeometry = f'+{int(x)+self.OFFSET}+{int(y)+self.OFFSET}'
        self.geometry(windowGeometry)
        self.wait_visibility()
        self.grab_set()
        self.focus()
        self.wm_attributes('-topmost', True)



class HexColor:

    @classmethod
    def get_luminance(cls, hexColor):
        color = hexColor[1:]
        hexRed = int(color[0:2], base=16)
        hexGreen = int(color[2:4], base=16)
        hexBlue = int(color[4:6], base=16)
        return hexRed * 0.2126 + hexGreen * 0.7152 + hexBlue * 0.0722

    @classmethod
    def is_dark(cls, hexColor):
        if cls.is_hex_color(hexColor):
            return cls.get_luminance(hexColor) < 140

        return None

    @classmethod
    def is_hex_color(cls, s):
        try:
            if len(s) == 7 and s.startswith('#'):
                return all(c in '0123456789abcdefABCDEF' for c in s[1:])

        except:
            return False



class MyStringVar(tk.StringVar):

    def set(self, value):
        if value is None:
            value = ''
        super().set(value)

    def get(self, default=None):
        value = super().get()
        if value == '':
            value = default
            if default is not None:
                self.set(default)
        return value
from tkinter import colorchooser


class PaletteView(ModalDialog):

    COLORS_PER_ROW = 8
    COLOR_FIELD_WIDTH = 5

    def __init__(self, chooser, ui, controller, title, initialcolor, **kw):

        def cancel():
            self.destroy()

        def choose_color():
            color = colorchooser.askcolor(
                parent=self,
                title=title,
                color=self._color,
            )[1]
            if color is not None:
                set_current_color(color)

        def contrast_color(c):
            contrastCol = '#ffffff' if HexColor.is_dark(c) else '#000000'
            return contrastCol

        def get_color_entry(event=None):
            color = self._colorVar.get()
            if HexColor.is_hex_color(color):
                set_current_color(color)
            else:
                self._colorVar.set(self._color)

        def on_quit(event=None):
            for child in self.winfo_children():
                child.destroy()
            self.destroy()

        def open_help_page(event=None):
            self._ctrl.open_help(
                page=HELP_PAGE,
                site=HELP_SITE
            )

        def return_color():
            self._chooser.color = self._color
            self.destroy()

        def set_current_color(color):
            self._color = color
            currentColorPreviewInv['bg'] = color
            currentColorPreviewInv['fg'] = contrast_color(color)
            currentColorPreview['fg'] = color
            self._colorVar.set(self._color)

        super().__init__(ui, **kw)
        self._ctrl = controller
        self.title(title)
        self.protocol("WM_DELETE_WINDOW", on_quit)

        self._chooser = chooser
        self._chooser.color = None
        self._color = initialcolor

        prefs = self._ctrl.get_preferences()
        initialcolor = initialcolor or prefs['color_text_fg']

        paletteArea = ttk.Frame(self)
        paletteArea.pack(fill='both', expand=True)

        ttk.Separator(
            self,
            orient='horizontal',
        ).pack(fill='x')

        previewWindow = ttk.Frame(self)
        previewWindow.pack(fill='both', expand=False)

        currentColorPreviewInv = tk.Label(
            previewWindow,
            text=_('Inverted display'),
            fg=contrast_color(initialcolor),
            bg=initialcolor,
        )
        currentColorPreviewInv.pack(side='right', fill='x', expand=True)

        currentColorPreview = tk.Label(
            previewWindow,
            text=_('Regular display'),
            fg=initialcolor,
            bg=prefs['color_text_bg'],
        )
        currentColorPreview.pack(side='left', fill='x', expand=True)

        colorEntryWindow = ttk.Frame(self)
        colorEntryWindow.pack(fill='both', expand=True)

        self._colorVar = MyStringVar(value=initialcolor)
        colorEntry = ttk.Entry(
            colorEntryWindow,
            textvariable=self._colorVar,
        )
        colorEntry.bind('<Return>', get_color_entry)
        colorEntry.pack(padx=5, pady=5, side='left')

        ttk.Button(
            colorEntryWindow,
            text=_('Color chooser'),
            command=choose_color,
        ).pack(
            padx=5,
            pady=5,
            side='right',
            fill='x',
            expand=True,
        )

        ttk.Separator(
            self,
            orient='horizontal',
        ).pack(fill='x')
        footer = tk.Frame(self)
        footer.pack(fill='both', expand=False)

        ttk.Button(
            footer,
            text=_('Cancel'),
            command=cancel,
        ).pack(padx=5, pady=5, side='right')

        ttk.Button(
            footer,
            text=_('Help'),
            command=open_help_page,
        ).pack(padx=5, pady=5, side='right')

        ttk.Button(
            footer,
            text=_('Apply'),
            command=return_color,
        ).pack(padx=5, pady=5, side='right')

        self.bind(KEYS.OPEN_HELP[0], open_help_page)

        for i, color in enumerate(COLORS):
            tk.Button(
                paletteArea,
                relief='flat',
                overrelief='raised',
                bg=color,
                width=self.COLOR_FIELD_WIDTH,
                command=lambda c=color: set_current_color(c),
            ).grid(
                row=i // self.COLORS_PER_ROW,
                column=i % self.COLORS_PER_ROW,
                padx=5,
                pady=5,
            )



def set_icon(widget, icon='logo', path=None, default=True):
    if path is None:
        path = os.path.dirname(sys.argv[0])
        if not path:
            path = '.'
        path = f'{path}/icons'
    try:
        pic = tk.PhotoImage(file=f'{path}/{icon}.png')
        widget.iconphoto(default, pic)
    except:
        return False

    return True



class NvColorChooser:

    def __init__(self, ui, controller):
        self._ui = ui
        self._ctrl = controller
        self.color = None

    def choose_color(self, title='', initialcolor=None):
        palette = PaletteView(self, self._ui, self._ctrl, title, initialcolor)
        set_icon(palette, icon='colors', default=False)
        palette.wait_window(palette)

        return self.color
from abc import ABC, abstractmethod
from pathlib import Path



class SubController:

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_open(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass



class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''
    HELP_SITE = None
    HELP_PAGE = None

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

        self._icon = None

    @abstractmethod
    def install(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def uninstall(self):
        pass

    def _add_help_menu_entry(self, label):

        def open_help():
            self._ctrl.open_help(
                page=self.HELP_PAGE,
                site=self.HELP_SITE
            )

        self._ui.helpMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            command=open_help,
        )

    def _get_icon(self, fileName):
        if self._ctrl.get_preferences().get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
            icon = tk.PhotoImage(file=f'{iconPath}/{fileName}')
        except:
            icon = None
        return icon


class Plugin(PluginBase):
    VERSION = '0.4.2'
    API_VERSION = '5.63'
    DESCRIPTION = 'Color palette dialog'
    URL = 'https://github.com/peter88213/nv_color_palette'
    HELP_SITE = HELP_SITE
    HELP_PAGE = HELP_PAGE

    def install(self, model, view, controller):
        """Install the plugin at runtime.
        
        Positional arguments:
            model -- reference to the novelibre main model instance.
            view -- reference to the novelibre main view instance.
            controller -- reference to the novelibre main controller instance.

        Extends the superclass method.
        """
        super().install(model, view, controller)
        self._icon = self._get_icon('colors.png')


        self._add_help_menu_entry(_('Color palette plugin help'))


        self._ui.colorChooser = NvColorChooser(self._ui, self._ctrl)

